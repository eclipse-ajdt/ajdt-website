This archive contains the source code for XXX, a presentation at EclipseCon 2009.  (URL)


The following files are contained in this archive:

* org.eclipse.ajdt.eclipsecon2009_1.0.0.jar --- The plugin that defines the ships editor
* org.eclipse.ajdt.shipsexample.zip --- A sample project that uses the ships editor
* org.eclipse.ajdt.eclipsecon2009.zip --- The eclipse project for the ships editor
* readme.txt --- this file


Requirements
1. Eclipse 3.4 or later
2. AJDT 1.6.4 or later
3. JDT Weaving service must be enabled

Installing the example
1. Install the ships editor plugin:
copy org.eclipse.ajdt.eclipsecon2009_1.0.0.jar into the eclipse/dropins/plugins directory.

2. Import the example project:
click on File -> Import -> Existing Projects into Workspace -> Next, then select org.eclipse.ajdt.shipsexample.zip

3. If you want to edit the source and create your own plugin that is built on the JDT Weaving Service, import org.eclipse.ajdt.eclipsecon2009.zip into your workspace